//
//  Loops_ChallengeApp.swift
//  Loops Challenge
//
//  Created by Margaret Hamilton on 10/12/21.
//

import SwiftUI

@main
struct Loops_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
